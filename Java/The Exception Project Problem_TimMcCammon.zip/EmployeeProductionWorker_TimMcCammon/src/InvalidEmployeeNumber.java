
/**
*This is the exception that is thrown by the employee class when it receives an employee number that is invalid.
* Date 2/16/21
* CSC 251 - The Exception Project Problem
* @author Tim McCammon
*/
public class InvalidEmployeeNumber extends Exception
{
    /**
      Constructor
     */
    public InvalidEmployeeNumber()
    {
        super("ERROR: Invalid employee number. ");
    }
}
