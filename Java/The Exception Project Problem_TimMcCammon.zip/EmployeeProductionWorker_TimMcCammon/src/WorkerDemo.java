/**
*Takes employee data and shows it in a readable format using objects and constructors
* Date 2/2/21
* CSC 251  - The Employee and Productionworker Classes Problem
* @author Tim McCammon
*/



public class WorkerDemo
{
    public static void main(String[] args)
    {
       createWorker("John Smith", "123-A", "11-15-2015", ProductionWorker.DAY_SHIFT, 26.50);
        
       System.out.println("\nAttempting an invalid employee number...");
        createWorker("John Smith", "10001", "11-15-2015", ProductionWorker.DAY_SHIFT, 26.50);
        
        System.out.println("\nAttempting an invalid shift number");
        createWorker("John Smith", "123-A", "11-15-2015", 66, 26.50);
        
        System.out.println("\nAttempting a negative pay rate...");
        createWorker("John Smith", "123-A", "11-15-2015", ProductionWorker.DAY_SHIFT, -99.00);
        
    }



public static void createWorker(String n, String num, String date, int sh, double rate)
{
ProductionWorker pw;
        //Attempt to create an instance of the ProductionWorker class and catch any resulting exInvalidPayRatetions
 try
{
    pw = new ProductionWorker(n, num, date, sh, rate);
     //if we make it here the object was created successfully 
        System.out.println("Object created.");
        System.out.println(pw);
}
catch (InvalidEmployeeNumber e)
{
System.out.println(e.getMessage());
}
catch (InvalidShift e)
{
System.out.println(e.getMessage());
}
catch (InvalidPayRate e)
{
System.out.println(e.getMessage());
        }
    }
} 