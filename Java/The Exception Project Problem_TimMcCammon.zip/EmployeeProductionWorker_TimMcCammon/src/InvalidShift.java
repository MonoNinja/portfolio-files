/**
*This is the exception that is thrown by the ProductionWorker class when it receives a shift number that is invalid.
* Date 2/16/21
* CSC 251 - The Exception Project Problem
* @author Tim McCammon
*/
public class InvalidShift extends Exception 
{
     /**
      Constructor
     */
    public InvalidShift()
    {
        super("ERROR: Invalid shift number." );
    }
    
}
