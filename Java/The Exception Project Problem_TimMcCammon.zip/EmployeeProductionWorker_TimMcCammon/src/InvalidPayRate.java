/**
*This is the exception that is thrown by the ProductionWorker class when it receives a negative pay rate.
* Date 2/16/21
* CSC 251 - The Exception Project Problem
* @author Tim McCammon
*/
public class InvalidPayRate extends Exception 
{

    /**
      Constructor
     */
    public InvalidPayRate()
    {
        super("ERROR: Negative pay rate. " );
    }
    
}