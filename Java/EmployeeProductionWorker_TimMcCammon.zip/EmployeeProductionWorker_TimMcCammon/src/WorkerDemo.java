/**
*Takes employee data and shows it in a readable format using objects and constructors
* Date 2/2/21
* CSC 251  - The Employee and Productionworker Classes Problem
* @author Tim McCammon
*/



public class WorkerDemo
{
    public static void main(String[] args)
    {
        ProductionWorker pw =
                new ProductionWorker("John Smith", "123-A", "11-15-2015", ProductionWorker.DAY_SHIFT, 26.50);
        System.out.println("Here's the first production worker. ");
        System.out.println(pw);
        
        
        ProductionWorker pw2 = new ProductionWorker();
        pw2.setName("Joan Jones");
        pw2.setEmployeeNumber("222-L");
        pw2.setHireDate("12-12-2015");
        pw2.setShift(ProductionWorker.NIGHT_SHIFT);
        pw2.setPayRate(28.50);
        
        System.out.println("\nHere's the second production worker.");
        System.out.println(pw2);
    }
}