
import java.util.Scanner;

/**
 A calculator that takes the markup percentage and adds it to the wholesale price, outputting a retail price.
 10/12/20
 CSC 151 Tutorial 5 - Retail Price Calculator Problem
 Author: Tim McCammon
*/


public class RetailPriceCalculator_TimMcCammon
{


    public static void main(String[] args)

    {



        Scanner keyboard = new Scanner(System.in);


        double wholesale;
        double markup;



         System.out.println("Welcome to the Retail Price Calculator: This program accepts a wholesale price "
                           + "and markup percentage,\n then calculates and displays the Retail Price ");

         System.out.println(" ");  //blank line for clarity purpose







         System.out.println("Please enter the wholesale cost: ");

         wholesale = keyboard.nextDouble();

         System.out.println(" ");  //blank line for clarity purpose



         System.out.println("Please enter the markup percentage. Example 100 for 100% , 2 for 2% )");

         markup = keyboard.nextDouble();

         System.out.println(" ");  //blank line for clarity purpose



         System.out.printf("The Retail price is: $%1$.2f", calculateRetail(wholesale,markup) ); // this output uses printf so we can format double to 2 decimal places, then sticks $ sign in front of upcoming  method return
                                                                                           // we run the method calculateRetail within the printf just to save unneeded extra amounts of code
         System.out.println(" ");  //blank line for clarity purpose

    }




     public static double calculateRetail(double wholesale, double markup) //public method, returns a double, accepts two double variables
     {

         double markup_amount; //holds markup amount
         double retail_price=0.00; //holds retail price that gets returned

         markup_amount = (markup/100)*wholesale; //calculates markup amount by multiplying wholesale times markup percentage

         retail_price = markup_amount+wholesale; //retail price is marked up amount + wholesale cost


         return(retail_price); //returns calculated retail price

     }




}