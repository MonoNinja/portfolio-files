/**
* Thia program takes a copy of an account object and replicates it.
* 1/8/21
* CSC 251 The BankAccount Class Copy Constructor Problem
* @author Tim McCammon
*/
public class BankAccountDemo 
{
    public static void main(String[] args)
    { 
    BankAccount account1 = new BankAccount(1200.0);
    
    BankAccount account2 = new BankAccount(account1);
    
    System.out.printf("The balance in account #1 is $%,.2f\n", account1.getBalance());
    
    System.out.printf("The balance in account #2 is $%,.2f\n", account2.getBalance());
    }
}
