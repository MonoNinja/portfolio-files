/**
* Thia program takes a copy of an account object and replicates it.
* 1/8/21
* CSC 251 The BankAccount Class Copy Constructor Problem
* @author Tim McCammon
*/
public class BankAccount
{
    private double balance;
    

    
    public BankAccount()
    {
        balance = 0.0;
    }
    

public BankAccount(BankAccount obj)
{
    balance = obj.balance;
} 

public BankAccount(double startBalance)
{
    balance = startBalance;
}

 public double getBalance() {
        return balance;
    }
}

