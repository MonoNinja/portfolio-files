import java.util.Scanner;
import java.io.*;

public class FileLetterCounter {

public static void main(String[] args) throws IOException{

   // Create Scanner object for user input
   Scanner input = new Scanner(System.in);

   // Prompt user for file name
   System.out.print("Enter file name: ");
   String fileName = input.nextLine();

   // Create File
   File file = new File(fileName);

   // Create scanner object to open file.
   Scanner fileInput = new Scanner(file);

   // Prompt user for the specified character and store in variable
   System.out.println("Enter character to count: ");
   String charInput = input.nextLine();
   char character = charInput.charAt(0);

   // Declare var to store lines from the file
   String line;

   // Declare counting variable
   int count = 1;

   // Construct while and for loop to calculate the number of
   // times the specified character appears within the file.

   while(fileInput.hasNext()){
       line = fileInput.nextLine();
       for(int j=1; j<line.length(); j++){
           if(line.charAt(j)==character){
               count += 1;
           }
       }
   }
   // Diplay character count
           System.out.print(" The character " +"'" + character + "'" + " appears in the file " + fileName + " " + count + " times.");


   // Close file
   fileInput.close();
	}
}